#include "TestScene.h"
#include "Engine/Camera.h"
#include "Engine/Input.h"
#include "Engine/Model.h"
#include "Engine/VFX.h"

//�R���X�g���N�^
TestScene::TestScene(GameObject * parent)
	: GameObject(parent, "TestScene"), hModel_(-1)
{
}

//������
void TestScene::Initialize()
{
	Camera::SetPosition(XMFLOAT3(0, 10, -15));
	Camera::SetTarget(XMFLOAT3(0, 0, 0));
	hModel_ = Model::Load("Ground.fbx");

	//��
	{
		EmitterData data;
		data.textureFileName = "cloudA.png";
		data.position = XMFLOAT3(-4, 4, 4);
		data.positionRnd = XMFLOAT3(0.1, 0, 0.1);
		data.delay = 5;
		data.number = 1;
		data.lifeTime = 60;
		data.gravity = -0.002f;
		data.direction = XMFLOAT3(0, 1, 0);
		data.directionRnd = XMFLOAT3(0, 0, 0);
		data.speed = 0.01f;
		data.speedRnd = 0.0;
		data.size = XMFLOAT2(1.5, 1.5);
		data.sizeRnd = XMFLOAT2(0.4, 0.4);
		data.scale = XMFLOAT2(1.01, 1.01);
		data.color = XMFLOAT4(1, 1, 0, 1);
		data.deltaColor = XMFLOAT4(0, -0.03, 0, -0.02);
		VFX::Start(data);

		//�΂̕�
		data.number = 3;
		data.positionRnd = XMFLOAT3(0.8, 0, 0.8);
		data.direction = XMFLOAT3(0, 1, 0);
		data.directionRnd = XMFLOAT3(10, 10, 10);
		data.size = XMFLOAT2(0.2, 0.2);
		data.scale = XMFLOAT2(0.95, 0.95);
		data.lifeTime = 120;
		data.speed = 0.1f;
		data.gravity = 0;
		VFX::Start(data);
	}


	//��
	{
		EmitterData data;

		data.textureFileName = "cloudA.png";
		data.position = XMFLOAT3(4, 1.5, 4);
		data.positionRnd = XMFLOAT3(0.1, 0, 0.1);
		data.delay = 5;
		data.number = 1;
		data.lifeTime = 150;
		data.direction = XMFLOAT3(0, 1, 0);
		data.directionRnd = XMFLOAT3(0, 0, 0);
		data.speed = 0.1f;
		data.accel = 0.98;
		data.speedRnd = 0.0;
		data.size = XMFLOAT2(2, 2);
		data.sizeRnd = XMFLOAT2(0.4, 0.4);
		data.scale = XMFLOAT2(1.01, 1.01);
		data.color = XMFLOAT4(1, 1, 1, 0.2);
		data.deltaColor = XMFLOAT4(0, 0, 0, -0.002);
		data.spin.z = 0.1;
		data.rotateRnd.z = 180;
		VFX::Start(data);
	}

	//��
	{
		EmitterData data;

		data.textureFileName = "Water.png";
		data.position = XMFLOAT3(4, 3.3, -4.5);
		data.delay = 1;
		data.number = 3;
		data.lifeTime = 50;
		data.direction = XMFLOAT3(0, 0, -1);
		data.directionRnd = XMFLOAT3(0, 0, 0);
		data.gravity = 0.005;
		data.speed = 0.1f;
		data.accel = 0.98;
		data.speedRnd = 0.0;
		data.size = XMFLOAT2(1, 1);
		data.sizeRnd = XMFLOAT2(0.8, 0.4);
		data.scale = XMFLOAT2(1.02, 1.02);
		data.color = XMFLOAT4(1, 1, 1, 0.1);
		VFX::Start(data);

		//���H
		data.textureFileName = "defaultParticle.png";
		data.position = XMFLOAT3(4, 3.3, -4.5);
		data.positionRnd = XMFLOAT3(0.5, 0, 0);
		data.delay = 1;
		data.number = 3;
		data.lifeTime = 50;
		data.direction = XMFLOAT3(0, 0, -1);
		data.directionRnd = XMFLOAT3(0, 20, 0);
		data.gravity = 0.005;
		data.speed = 0.1f;
		data.accel = 0.98;
		data.speedRnd = 0.0;
		data.size = XMFLOAT2(0.2, 0.2);
		data.sizeRnd = XMFLOAT2(0, 0);
		data.scale = XMFLOAT2(0.98, 0.98);
		data.color = XMFLOAT4(0.5, 1, 1, 1);
		VFX::Start(data);
	}

	//����
	{
		EmitterData data;
		data.textureFileName = "RingCloud.png";
		data.position = XMFLOAT3(-4, 2.0, -4.5);
		data.rotate.x = 90;
		data.delay = 2;
		data.speed = 0.1f;
		data.accel = 0.98;
		data.size = XMFLOAT2(2, 2);
		data.sizeRnd = XMFLOAT2(0.3, 0.3);
		data.scale = XMFLOAT2(1.02, 1.02);
		data.color = XMFLOAT4(1, 1, 1, 0.2);
		data.deltaColor = XMFLOAT4(0, 0, 0, -0.003);
		data.lifeTime = 100;
		data.spin.z = -4;
		data.rotateRnd.z = 180;
		data.isBillBoard = false;
		VFX::Start(data);
	}
}

//�X�V
void TestScene::Update()
{
	//����
	if (Input::IsKeyDown(DIK_SPACE))
	{
		
		EmitterData data;

		//��
		data.textureFileName = "cloudA.png";
		data.position = XMFLOAT3(0, 0.05, 0);
		data.delay = 0;
		data.number = 80;
		data.lifeTime = 30;
		data.direction = XMFLOAT3(0, 1, 0);
		data.directionRnd = XMFLOAT3(90, 90, 90);
		data.speed = 0.1f;
		data.speedRnd = 0.8;
		data.size = XMFLOAT2(1.2, 1.2);
		data.sizeRnd = XMFLOAT2(0.4, 0.4);
		data.scale = XMFLOAT2(1.05, 1.05);
		data.color = XMFLOAT4(1, 1, 0.1, 1);
		data.deltaColor = XMFLOAT4(0, -1.0 / 20, 0, -1.0 / 20);
		VFX::Start(data);

		//�΂̕�
		data.delay = 0;
		data.number = 80;
		data.lifeTime = 100;
		data.positionRnd = XMFLOAT3(0.5, 0, 0.5);
		data.direction = XMFLOAT3(0, 1, 0);
		data.directionRnd = XMFLOAT3(90, 90, 90);
		data.speed = 0.25f;
		data.speedRnd = 1;
		data.accel = 0.93;
		data.size = XMFLOAT2(0.1, 0.1);
		data.sizeRnd = XMFLOAT2(0.4, 0.4);
		data.scale = XMFLOAT2(0.99, 0.99);
		data.color = XMFLOAT4(1, 1, 0.1, 1);
		data.deltaColor = XMFLOAT4(0, 0, 0, 0);
		data.gravity = 0.003f;
		VFX::Start(data);

		//�n��
		data.textureFileName = "flashA_R.png";
		data.positionRnd = XMFLOAT3(0, 0, 0);
		data.isBillBoard = false;
		data.rotate.x = 90;
		data.delay = 0;
		data.number = 1;
		data.lifeTime = 7;
		data.speed = 0;
		data.size = XMFLOAT2(5, 5);
		data.sizeRnd = XMFLOAT2(0, 0);
		data.scale = XMFLOAT2(1.25f, 1.25f);
		data.color = XMFLOAT4(1, 1, 1, 0.3f);
		VFX::Start(data);
	}

}

//�`��
void TestScene::Draw()
{
	Model::SetTransform(hModel_, transform_);
	Model::Draw(hModel_);
}

//�J��
void TestScene::Release()
{
}
